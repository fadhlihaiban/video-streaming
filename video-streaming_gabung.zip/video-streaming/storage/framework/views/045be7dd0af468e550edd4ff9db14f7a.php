<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('🎬 Daftar Video & Status Akses')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <?php if(session('success')): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>
            <?php if(session('error') || session('warning')): ?>
                <div class="bg-yellow-100 border border-yellow-400 text-yellow-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline"><?php echo e(session('error') ?? session('warning')); ?></span>
                </div>
            <?php endif; ?>
            
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <h3 class="text-2xl font-bold mb-6">Video yang Tersedia</h3>

                    
                    <?php $__empty_1 = true; $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $request_status = $user_requests->get($video->id);
                        ?>

                        <div class="border p-4 mb-4 rounded shadow-md flex justify-between items-center transition duration-150 ease-in-out hover:bg-gray-50">
                            
                            <div class="flex items-start space-x-4"> 
                                
                               
                                <div class="flex-shrink-0 w-32 h-20 overflow-hidden rounded-md">
                                    
                                    <img src="https://img.youtube.com/vi/<?php echo e($video->youtube_id); ?>/mqdefault.jpg" 
                                        alt="Thumbnail: <?php echo e($video->title); ?>" 
                                        class="w-full h-full object-cover">
                                </div>

                                <div>
                                    <h4 class="text-xl font-semibold"><?php echo e($video->title); ?></h4>
                                    <p class="text-sm text-gray-600 hidden sm:block">ID YouTube: <?php echo e($video->youtube_id); ?></p>
                                    
                                    <p class="mt-2 text-sm font-bold">Status Akses:
                                        <?php if($request_status && $request_status->status == 'approved' && now()->lessThan($request_status->approved_until)): ?>
                                            <span class="text-green-600">Disetujui! (Berakhir: <?php echo e($request_status->approved_until->format('d M Y')); ?>)</span>
                                        <?php elseif($request_status && $request_status->status == 'pending'): ?>
                                            <span class="text-yellow-600">Menunggu Persetujuan Admin.</span>
                                        <?php elseif($request_status && $request_status->status == 'rejected'): ?>
                                            <span class="text-red-600">Ditolak.</span>
                                        <?php else: ?>
                                            <span class="text-gray-500">Belum diajukan.</span>
                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>

                            <div class="flex-shrink-0">
                                
                                <?php if($request_status && $request_status->status == 'approved' && now()->lessThan($request_status->approved_until)): ?>
                                    <a href="<?php echo e(route('customer.watch', $video)); ?>" class="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded transition duration-150">
                                        Tonton Sekarang
                                    </a>
                                <?php else: ?>
                                    <form method="POST" action="<?php echo e(route('customer.request.store', $video)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" 
                                            <?php if($request_status && ($request_status->status == 'pending')): ?>
                                                disabled class="bg-gray-400 py-2 px-4 rounded cursor-not-allowed"
                                            <?php else: ?>
                                                class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded transition duration-150"
                                            <?php endif; ?>
                                        >
                                            <?php if($request_status && $request_status->status == 'rejected'): ?>
                                                Ajukan Ulang
                                            <?php else: ?>
                                                Minta Akses
                                            <?php endif; ?>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-gray-500">Belum ada video yang ditambahkan oleh Admin.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH F:\Lain-Lain\Latihan\web\laravel\video_streaming\video-streaming\resources\views/customer/videos/index.blade.php ENDPATH**/ ?>